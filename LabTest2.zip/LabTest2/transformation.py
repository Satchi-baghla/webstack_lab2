from lxml import etree
import xmlschema


# Load the XML and XSLT files
xml_file = "D:/MCA/Web Stack/LabTest2/jokes.xml"
xslt_file = "D:/MCA/Web Stack/LabTest2/transform.xsl"

transformer = etree.XSLT(etree.parse(xslt_file))

result_tree = transformer(etree.parse(xml_file))

output_html_file = "D:/MCA/Web Stack/LabTest2/output.html"
result_tree.write(output_html_file, pretty_print=True)

print(f"Transformation complete. HTML saved as {output_html_file}")