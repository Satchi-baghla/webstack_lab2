import xmlschema

xml_file_path = "D:/MCA/Web Stack/LabTest2/jokes.xml"
xsd_file_path = "D:/MCA/Web Stack/LabTest2/jokes.xsd"

schema = xmlschema.XMLSchema(xsd_file_path)
if schema.is_valid(xml_file_path):
    print(f"{xml_file_path} is valid against {xsd_file_path}.")
else:
    print(f"{xml_file_path} is not valid against {xsd_file_path}.")