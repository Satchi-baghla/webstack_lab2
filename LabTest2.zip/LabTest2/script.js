function fetchData() {
    console.log("dwd");
    const url = "https://v2.jokeapi.dev/joke/Any";
    const httpRequest = new XMLHttpRequest();
    httpRequest.open("GET", url, true);
    console.log("dwd");
    // Set up event listener to handle response
    httpRequest.onreadystatechange = function () {
      if (httpRequest.readyState === XMLHttpRequest.DONE) {
        if (httpRequest.status === 200) {
          const response = JSON.parse(httpRequest.responseText);
          console.log(response);
          displayData(response);
        } else {
          console.error("Error:", httpRequest.status);
        }
      }
    };
    httpRequest.send();
  }
  
  function displayData(data) {
    const outputDiv = document.getElementById("output");
    outputDiv.innerHTML = data["category"];
  
  }